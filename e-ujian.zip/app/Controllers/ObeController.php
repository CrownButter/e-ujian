<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\BankSoalModel;

class ObeController extends BaseController
{
    protected $bankSoalModel;

    // Pemetaan Role
    protected $roleMap = [
        1 => 'admin',
        2 => 'operator',
        3 => 'gadik',
        4 => 'danton',
        5 => 'danki',
        6 => 'danyon',
        7 => 'siswa'
    ];

    public function __construct()
    {
        $this->bankSoalModel = model(BankSoalModel::class);
    }

    protected function getRolePrefix()
    {
        $roleId = (int) session()->get('role_id');
        return $this->roleMap[$roleId] ?? 'admin';
    }

    // ========================================================================
    // MANAJEMEN BANK SOAL (C1 s/d C6)
    // ========================================================================

    public function bankSoalIndex()
    {
        $rolePrefix = $this->getRolePrefix();

        $data = [
            'title'       => 'Bank Soal OBE (C1 - C6)',
            'page_title'  => 'Manajemen Bank Soal',
            'role_prefix' => $rolePrefix,
        ];

        return view('obe/bank_soal', $data);
    }

    /**
     * API: Ambil semua soal berdasarkan Level (C1 - C6)
     */
    public function bankSoalGetByLevel($level)
    {
        try {
            // Menggunakan kolom 'tingkat_taksonomi' sesuai struktur tabel 'soal_obe'
            $soal = $this->bankSoalModel
                ->where('tingkat_taksonomi', strtoupper($level))
                ->orderBy('id', 'ASC')
                ->findAll();

            return $this->response->setJSON([
                'status' => true,
                'data'   => $soal
            ]);
        } catch (\Throwable $th) {
            return $this->response->setStatusCode(500)->setJSON([
                'status'  => false,
                'message' => 'Database Error: ' . $th->getMessage(),
                'file'    => $th->getFile(),
                'line'    => $th->getLine()
            ]);
        }
    }


    public function bankSoalStore()
    {
        $rules = [
            'level_soal' => 'required|in_list[C1,C2,C3,C4,C5,C6]',
            'pertanyaan' => 'required',
            'jawaban'    => 'required'
        ];

        // Jika validasi gagal, kembalikan response beserta csrf_token baru
        if (!$this->validate($rules)) {
            return $this->response->setJSON([
                'status'     => false,
                'message'    => 'Pertanyaan dan Kunci Jawaban wajib diisi!',
                'csrf_token' => csrf_hash()
            ]);
        }

        try {
            $id    = $this->request->getPost('id_soal');
            $level = strtoupper($this->request->getPost('level_soal'));

            // --- PENANGANAN CREATED_BY (FOREIGN KEY PEGAWAI) ---
            $db = \Config\Database::connect();
            $userPegawaiId = session()->get('pegawai_id') ?? session()->get('user_id');

            // Cek apakah ID dari session valid di tabel pegawai
            $validPegawai = null;
            if (!empty($userPegawaiId)) {
                $validPegawai = $db->table('pegawai')->where('id', $userPegawaiId)->get()->getRow();
            }

            // Jika session tidak cocok, ambil ID pertama dari tabel pegawai
            if (!$validPegawai) {
                $firstPegawai = $db->table('pegawai')->select('id')->get()->getRow();

                if (!$firstPegawai) {
                    return $this->response->setStatusCode(500)->setJSON([
                        'status'     => false,
                        'message'    => 'Gagal: Tabel pegawai masih kosong! Silakan isi data pegawai terlebih dahulu.',
                        'csrf_token' => csrf_hash()
                    ]);
                }
                $userPegawaiId = $firstPegawai->id;
            }

            $data = [
                'tingkat_taksonomi' => $level,
                'pertanyaan'        => $this->request->getPost('pertanyaan'),
                'rubrik_penilaian'  => $this->request->getPost('jawaban'),
                'mapel_id'          => null,
                'cpmk'              => $this->request->getPost('cpmk') ?? 'CPMK-' . $level,
                'cpl'               => $this->request->getPost('cpl') ?? 'CPL-DEFAULT',
                'bobot_soal'        => $this->request->getPost('bobot_soal') ?? 0.00,
                'created_by'        => $userPegawaiId
            ];

            // Eksekusi Update atau Insert
            if (!empty($id)) {
                $this->bankSoalModel->update($id, $data);
                $message = 'Soal tingkat ' . $level . ' berhasil diperbarui.';
            } else {
                $this->bankSoalModel->insert($data);
                $message = 'Soal tingkat ' . $level . ' berhasil ditambahkan.';
            }

            // KUNCI PERBAIKAN: Sertakan 'csrf_token' => csrf_hash()
            return $this->response->setJSON([
                'status'     => true,
                'message'    => $message,
                'csrf_token' => csrf_hash()
            ]);
        } catch (\Throwable $th) {
            return $this->response->setStatusCode(500)->setJSON([
                'status'     => false,
                'message'    => 'Gagal menyimpan: ' . $th->getMessage(),
                'csrf_token' => csrf_hash()
            ]);
        }
    }

    /**
     * API: Ambil detail 1 soal berdasarkan ID (Untuk diisikan ke Form Edit)
     */
    public function bankSoalGetDetail($id)
    {
        try {
            $soal = $this->bankSoalModel->find($id);

            if (!$soal) {
                return $this->response->setStatusCode(404)->setJSON([
                    'status'  => false,
                    'message' => 'Data soal tidak ditemukan.'
                ]);
            }

            return $this->response->setJSON([
                'status' => true,
                'data'   => $soal
            ]);
        } catch (\Throwable $th) {
            return $this->response->setStatusCode(500)->setJSON([
                'status'  => false,
                'message' => 'Gagal mengambil data: ' . $th->getMessage()
            ]);
        }
    }
    /**
     * API/Proses: Hapus Soal
     */
    public function bankSoalDelete($id)
    {
        try {
            $soal = $this->bankSoalModel->find($id);
            if ($soal) {
                $this->bankSoalModel->delete($id);
                return $this->response->setJSON([
                    'status'  => true,
                    'message' => 'Soal berhasil dihapus.'
                ]);
            }

            return $this->response->setJSON([
                'status'  => false,
                'message' => 'Data soal tidak ditemukan.'
            ]);
        } catch (\Throwable $th) {
            return $this->response->setStatusCode(500)->setJSON([
                'status'  => false,
                'message' => 'Gagal menghapus: ' . $th->getMessage()
            ]);
        }
    }

    // ========================================================================
    // FITUR UJIAN LAINNYA
    // ========================================================================

    public function bobotNilaiIndex()
    {
        $rolePrefix = $this->getRolePrefix();
        return view('obe/bobot_nilai', [
            'title'       => 'Konfigurasi Bobot Nilai OBE',
            'page_title'  => 'Bobot Nilai Tingkat Kognitif (C1-C6)',
            'role_prefix' => $rolePrefix
        ]);
    }

    /**
     * Menangani proses simpan pengaturan bobot via AJAX
     */
    public function bobotNilaiStore()
    {
        // Tangkap data yang dikirim dari AJAX JS
        $postData = $this->request->getPost();

        // TODO: Silakan tambahkan logika penyimpanan ke Database di sini jika sudah ada tabelnya.
        // Contoh: $this->bobotModel->save($postData);

        // Kirim respons JSON ke AJAX beserta token CSRF baru
        return $this->response->setJSON([
            'status'     => true,
            'message'    => 'Pengaturan bobot dimensi berhasil disimpan!',
            'csrf_token' => csrf_hash()
        ]);
    }

    public function jadwalUjianIndex()
    {
        $rolePrefix = $this->getRolePrefix();

        // Ambil data mata pelajaran dari database
        $db = \Config\Database::connect();
        $mataPelajaran = $db->table('mata_pelajaran')->get()->getResultArray();

        return view('obe/jadwal_ujian', [
            'title'          => 'Jadwal & Waktu Ujian OBE',
            'page_title'     => 'Set Jadwal & Deadline Ujian',
            'role_prefix'    => $rolePrefix,
            'mata_pelajaran' => $mataPelajaran // Masukkan ke sini
        ]);
    }

    public function siswaDaftarUjian()
    {
        return view('siswa/obe/daftar_ujian', [
            'title'       => 'Daftar Ujian OBE Aktif',
            'page_title'  => 'Ikuti Ujian',
            'role_prefix' => 'siswa'
        ]);
    }

    public function siswaRiwayatUjian()
    {
        return view('siswa/obe/riwayat_ujian', [
            'title'       => 'Riwayat Ujian OBE Anda',
            'page_title'  => 'Hasil Ujian',
            'role_prefix' => 'siswa'
        ]);
    }

    // ========================================================================
    // API UNTUK JADWAL UJIAN
    // ========================================================================

    public function jadwalUjianGetData()
    {
        // Ganti 'JadwalUjianModel' dengan nama model Anda yang sebenarnya
        $model = model('JadwalUjianModel');
        $data = $model->findAll();

        return $this->response->setJSON([
            'status' => true,
            'data'   => $data
        ]);
    }

    public function jadwalUjianStore()
    {
        var_dump($this->request->getPost('mata_pelajaran_id'));
        exit;
        try {
            $model = model('JadwalUjianModel');
            $id    = $this->request->getPost('id');

            // Cek data mentah yang dikirim dari form/AJAX
            $mapelId = $this->request->getPost('mata_pelajaran_id');

            // Hentikan sementara untuk cek via console response network (lihat tab Preview/Response di browser)
            if (empty($mapelId)) {
                return $this->response->setStatusCode(400)->setJSON([
                    'status' => false,
                    'message' => 'Debug: mata_pelajaran_id kosong atau tidak terkirim!',
                    'all_post' => $this->request->getPost()
                ]);
            }

            $data = [
                'mata_pelajaran_id' => $mapelId,
                'angkatan_id'       => 1,
                'nama_ujian'        => 'Ujian OBE',
                'tanggal_mulai'     => $this->request->getPost('tanggal_ujian') . ' ' . $this->request->getPost('waktu_mulai'),
                'tanggal_selesai'   => $this->request->getPost('tanggal_ujian') . ' ' . $this->request->getPost('waktu_selesai'),
                'durasi_menit'      => $this->request->getPost('durasi_menit'),
                'status_ujian'      => $this->request->getPost('status'),
                'tingkat_kognitif'  => $this->request->getPost('tingkat_kognitif'),
            ];

            if (!empty($id)) {
                $model->update($id, $data);
                $msg = 'Jadwal berhasil diperbarui!';
            } else {
                $model->insert($data);
                $msg = 'Jadwal berhasil ditambahkan!';
            }

            return $this->response->setJSON([
                'status'     => true,
                'message'    => $msg,
                'csrf_token' => csrf_hash()
            ]);
        } catch (\Throwable $th) {
            return $this->response->setStatusCode(500)->setJSON([
                'status'     => false,
                'message'    => 'Error Database: ' . $th->getMessage() . ' (Line: ' . $th->getLine() . ')',
                'csrf_token' => csrf_hash()
            ]);
        }
    }

    public function jadwalUjianGet($id)
    {
        $model = model('JadwalUjianModel');
        $data  = $model->find($id);

        return $this->response->setJSON([
            'status' => true,
            'data'   => $data
        ]);
    }

    public function jadwalUjianDelete($id)
    {
        $model = model('JadwalUjianModel');
        $model->delete($id);

        return $this->response->setJSON([
            'status'     => true,
            'message'    => 'Data jadwal berhasil dihapus!',
            'csrf_token' => csrf_hash()
        ]);
    }
}
