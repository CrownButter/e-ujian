<?php

namespace App\Models;

use CodeIgniter\Model;

class SiswaModel extends Model
{
    protected $table            = 'siswa';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;

    protected $allowedFields = [
        'user_id',
        'nama',
        'nosis',
        'pleton_id',
        'angkatan_id'
    ];

    protected $useTimestamps = false;

    /**
     * Menampilkan data siswa beserta nama pleton dan angkatan
     */
    public function getSiswaWithPleton()
    {
        return $this->select('
                    siswa.*,
                    pleton.nama_pleton,
                    angkatan.tahun_angkatan
                ')
            ->join('pleton', 'pleton.id = siswa.pleton_id', 'left')
            ->join('angkatan', 'angkatan.id = siswa.angkatan_id', 'left')
            ->findAll();
    }

    /**
     * Mengambil siswa yang belum memiliki pleton
     */
    public function getSiswaBelumPleton()
    {
        return $this->where('pleton_id', null)
            ->orWhere('pleton_id', 0)
            ->findAll();
    }

    /**
     * Assign siswa ke pleton secara massal
     *
     * @param array $siswaIds
     * @param int $pletonId
     * @return bool
     */

    public function assignPleton(array $siswaIds, int $pletonId)
    {
        if (empty($siswaIds) || $pletonId <= 0) {
            return false;
        }

        return $this->db->table($this->table)
            ->whereIn('id', $siswaIds)
            ->update(['pleton_id' => $pletonId]);
    }

    /**
     * Menghapus siswa dari pleton
     */
    public function removePleton(array $siswaIds)
    {
        if (empty($siswaIds)) {
            return false;
        }

        return $this->builder()
            ->whereIn('id', $siswaIds)
            ->update([
                'pleton_id' => null
            ]);
    }

    /**
     * Mengambil seluruh siswa berdasarkan pleton
     */
    public function getByPleton($pletonId)
    {
        return $this->where('pleton_id', $pletonId)
            ->findAll();
    }

    /**
     * Mengambil siswa berdasarkan angkatan
     * beserta nama pleton
     */
    public function getSiswaByAngkatanAktif($angkatanId = null)
    {
        $builder = $this->select('
                siswa.*,
                pleton.nama_pleton,
                angkatan.tahun_angkatan
            ')
            ->join('pleton', 'pleton.id = siswa.pleton_id', 'left')
            ->join('angkatan', 'angkatan.id = siswa.angkatan_id', 'left');

        // Jika ada filter angkatan
        if (!empty($angkatanId)) {
            $builder->where('siswa.angkatan_id', $angkatanId);
        }

        return $builder->findAll();
    }
}
